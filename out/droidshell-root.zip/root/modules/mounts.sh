#!/usr/bin/env bash
set -euo pipefail
su -c "mount"
