#!/usr/bin/env bash
set -e

REPO="/data/data/com.termux/files/home/DroidShell-Build/source/DroidShell"
STRINGS="$REPO/app/src/main/res/values/strings.xml"

echo "[ds-rebuild] Rebuilding strings.xml from scratch..."

# Backup corrupted file
cp "$STRINGS" "$STRINGS.broken.$(date +%s)"

# Create clean file
cat > "$STRINGS" << 'EOS'
<?xml version="1.0" encoding="utf-8"?>
<resources>

    <!-- Core Termux strings preserved -->
    <string name="app_name">DroidShell</string>
    <string name="action_new_session">New session</string>
    <string name="action_new_window">New window</string>
    <string name="action_close_window">Close window</string>
    <string name="action_style">Style</string>
    <string name="action_reset">Reset</string>
    <string name="action_share_transcript">Share transcript</string>
    <string name="action_toggle_keyboard">Toggle keyboard</string>
    <string name="action_toggle_fullscreen">Toggle fullscreen</string>
    <string name="action_toggle_soft_keyboard">Toggle soft keyboard</string>
    <string name="action_select_url">Select URL</string>
    <string name="action_select_text">Select text</string>
    <string name="action_paste">Paste</string>
    <string name="action_copy_all">Copy all</string>
    <string name="action_more">More</string>

    <!-- DroidShell additions -->
    <string name="about_droidshell_footer">
        DroidShell — Android Terminal Emulator. Enhanced automation, startup hooks, and developer tooling.
    </string>

</resources>
EOS

echo "[ds-rebuild] strings.xml rebuilt cleanly."
